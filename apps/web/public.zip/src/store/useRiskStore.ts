import { create } from "zustand";
import type { ArteryId } from "../config/arteries";

type Probabilities = Record<ArteryId, number>;

interface RiskState {
  probabilities: Probabilities;
  selected: ArteryId | null;
  setProbability: (id: ArteryId, value: number) => void;
  setAll: (p: Probabilities) => void;
  select: (id: ArteryId | null) => void;
}

export const useRiskStore = create<RiskState>((set) => ({
  probabilities: { LAD: 0.5, LCX: 0.5, RCA: 0.5 },
  selected: null,
  setProbability: (id, value) =>
    set((s) => ({ probabilities: { ...s.probabilities, [id]: value } })),
  setAll: (p) => set({ probabilities: p }),
  select: (id) => set({ selected: id }),
}));
