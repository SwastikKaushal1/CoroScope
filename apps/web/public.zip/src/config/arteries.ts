export type ArteryId = "LAD" | "LCX" | "RCA";

export interface ArteryDef {
  id: ArteryId;
  label: string;
  supplies: string;
  /**
   * 3D waypoints in the heart's scene space (the heart is about 1 wide, 2 tall,
   * 1.3 deep, centred on 0,0,0, with the front facing +z). Paste the lines printed
   * by the click-picker here. Each point is snapped onto the heart surface at runtime,
   * so small errors are fine.
   * Viewer's left = patient's right.
   */
  waypoints: [number, number, number][];
}

export const ARTERIES: ArteryDef[] = [
  {
    id: "LAD",
    label: "Left anterior descending",
    supplies: "Front of the heart",
    // ROUGH STARTER POINTS: replace with picked ones
    waypoints: [
      [0.05, 0.15, 0.6],
      [0.1, -0.1, 0.6],
      [0.15, -0.4, 0.5],
      [0.2, -0.7, 0.35],
      [0.22, -0.9, 0.2],
    ],
  },
  {
    id: "LCX",
    label: "Left circumflex",
    supplies: "Side and back of the heart",
    // ROUGH STARTER POINTS: replace with picked ones
    waypoints: [
      [0.15, 0.3, 0.45],
      [0.35, 0.2, 0.4],
      [0.45, 0.0, 0.2],
      [0.45, -0.1, -0.1],
    ],
  },
  {
    id: "RCA",
    label: "Right coronary artery",
    supplies: "Right side and bottom of the heart",
    // ROUGH STARTER POINTS: replace with picked ones
    waypoints: [
      [-0.2, 0.3, 0.5],
      [-0.35, 0.1, 0.45],
      [-0.4, -0.2, 0.35],
      [-0.35, -0.5, 0.3],
    ],
  },
];

export const ARTERY_IDS = ARTERIES.map((a) => a.id);