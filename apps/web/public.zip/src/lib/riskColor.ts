import * as THREE from "three";

// Green -> amber -> red. These are display colors, not clinical thresholds.
const LOW = new THREE.Color("#2f9e6b");
const MID = new THREE.Color("#f2b134");
const HIGH = new THREE.Color("#e5484d");

/** Map a probability (0-1) to a color. Pass `out` to avoid allocating. */
export function riskColor(p: number, out = new THREE.Color()): THREE.Color {
  const t = Math.min(1, Math.max(0, p));
  return t < 0.5
    ? out.copy(LOW).lerp(MID, t / 0.5)
    : out.copy(MID).lerp(HIGH, (t - 0.5) / 0.5);
}

/** Same color as a CSS hex string, for normal HTML elements. */
export const riskColorHex = (p: number) => `#${riskColor(p).getHexString()}`;

export function riskLevel(p: number): "Low" | "Moderate" | "High" {
  return p < 0.35 ? "Low" : p < 0.65 ? "Moderate" : "High";
}
