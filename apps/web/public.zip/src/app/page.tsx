"use client";

import dynamic from "next/dynamic";
import { ARTERIES } from "@/config/arteries";
import { riskColorHex, riskLevel } from "@/lib/riskColor";
import { useRiskStore } from "@/store/useRiskStore";

// three.js needs the browser (WebGL), so never render the canvas on the server.
const Scene = dynamic(() => import("@/components/three/Scene"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center text-sm text-gray-500">Loading 3D view…</div>
  ),
});

export default function Home() {
  const probabilities = useRiskStore((s) => s.probabilities);
  const selected = useRiskStore((s) => s.selected);
  const setProbability = useRiskStore((s) => s.setProbability);
  const setAll = useRiskStore((s) => s.setAll);
  const select = useRiskStore((s) => s.select);
  const selectedDef = ARTERIES.find((a) => a.id === selected);

  return (
    <div className="flex h-screen flex-col bg-white text-gray-900">
      <div className="bg-amber-100 px-4 py-2 text-center text-sm text-amber-900">
        Decision support and educational use only. Not a substitute for formal diagnostic imaging.
      </div>

      <main className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[1fr_340px]">
        <section className="min-h-[320px] bg-gray-50">
          <Scene />
        </section>

        <aside className="space-y-5 overflow-y-auto border-l border-gray-200 p-5">
          <div>
            <h1 className="text-lg font-semibold">CoroScope</h1>
            <p className="text-sm text-gray-500">Milestone 1: test the 3D heart with manual probabilities.</p>
          </div>

          <div className="flex gap-2">
            <button
              className="rounded border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-100"
              onClick={() => setAll({ LAD: 0.82, LCX: 0.38, RCA: 0.66 })}
            >
              High-risk demo
            </button>
            <button
              className="rounded border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-100"
              onClick={() => setAll({ LAD: 0.09, LCX: 0.07, RCA: 0.11 })}
            >
              Low-risk demo
            </button>
          </div>

          <div className="space-y-4">
            {ARTERIES.map((a) => {
              const p = probabilities[a.id];
              return (
                <div key={a.id}>
                  <div className="mb-1 flex items-center justify-between text-sm">
                    <span className="font-medium">{a.id}</span>
                    <span className="flex items-center gap-2">
                      <span className="inline-block h-3 w-3 rounded-full" style={{ background: riskColorHex(p) }} />
                      {Math.round(p * 100)}% · {riskLevel(p)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={1}
                    value={Math.round(p * 100)}
                    onChange={(e) => setProbability(a.id, Number(e.target.value) / 100)}
                    className="w-full"
                    aria-label={`${a.id} probability`}
                  />
                </div>
              );
            })}
          </div>

          <div className="rounded-lg border border-gray-200 p-3 text-sm">
            {selectedDef ? (
              <>
                <div className="font-medium">
                  {selectedDef.id}: {selectedDef.label}
                </div>
                <div className="text-gray-500">Supplies: {selectedDef.supplies}</div>
                <div className="mt-1">
                  Predicted risk: {Math.round(probabilities[selectedDef.id] * 100)}% ·{" "}
                  {riskLevel(probabilities[selectedDef.id])}
                </div>
                <button className="mt-2 text-xs text-gray-500 underline" onClick={() => select(null)}>
                  Clear selection
                </button>
              </>
            ) : (
              <span className="text-gray-500">Click an artery in the 3D view to inspect it.</span>
            )}
          </div>
        </aside>
      </main>
    </div>
  );
}
