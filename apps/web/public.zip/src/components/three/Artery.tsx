"use client";

import { useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { Html } from "@react-three/drei";
import { useFrame, type ThreeEvent } from "@react-three/fiber";
import type { ArteryDef } from "@/config/arteries";
import { riskColor } from "@/lib/riskColor";
import { useRiskStore } from "@/store/useRiskStore";

  const VISIBLE_RADIUS = 0.022;
const HIT_RADIUS = 0.05; // a fatter invisible tube, so thin arteries are easy to click

interface Props {
  def: ArteryDef;
  curve: THREE.CatmullRomCurve3;
}

export default function Artery({ def, curve }: Props) {
  const probability = useRiskStore((s) => s.probabilities[def.id]);
  const isSelected = useRiskStore((s) => s.selected === def.id);
  const select = useRiskStore((s) => s.select);
  const [hovered, setHovered] = useState(false);

  const material = useRef<THREE.MeshStandardMaterial>(null);

  const target = useMemo(() => riskColor(probability), [probability]);

  const tubeGeometry = useMemo(
    () => new THREE.TubeGeometry(curve, 120, VISIBLE_RADIUS, 12, false),
    [curve]
  );
  const hitGeometry = useMemo(
    () => new THREE.TubeGeometry(curve, 60, HIT_RADIUS, 8, false),
    [curve]
  );

  // Label floats just outside the heart, in the direction away from its centre.
  const labelPosition = useMemo(() => {
    const p = curve.getPoint(0.5);
    return p.clone().add(p.clone().normalize().multiplyScalar(0.12));
  }, [curve]);

  useFrame((_, delta) => {
    const m = material.current;
    if (!m) return;
    const k = 1 - Math.exp(-8 * delta);
    m.color.lerp(target, k);
    m.emissive.lerp(target, k);
    const glow = isSelected ? 0.7 : hovered ? 0.45 : 0.15;
    m.emissiveIntensity = THREE.MathUtils.lerp(m.emissiveIntensity, glow, k);
  });

  const onOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHovered(true);
    document.body.style.cursor = "pointer";
  };
  const onOut = () => {
    setHovered(false);
    document.body.style.cursor = "auto";
  };
  const onClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    select(isSelected ? null : def.id);
  };

  return (
    <group>
      {/* Visible artery. Starts gray and fades to its risk color on load. */}
      <mesh geometry={tubeGeometry}>
        <meshStandardMaterial ref={material} color="#8a8f98" roughness={0.35} />
      </mesh>

      {/* Invisible, fatter copy that receives the mouse events. */}
      <mesh geometry={hitGeometry} onPointerOver={onOver} onPointerOut={onOut} onClick={onClick}>
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>

      {/* Floating label. occlude hides it when the heart is in front of it. */}
      <Html position={labelPosition} center distanceFactor={4} style={{ pointerEvents: "none" }}>
        <div className="whitespace-nowrap rounded bg-black/70 px-1.5 py-0.5 text-[11px] font-medium text-white">
          {def.id} {Math.round(probability * 100)}%
        </div>
      </Html>
    </group>
  );
}