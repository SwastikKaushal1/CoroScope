import * as THREE from "three";
import { mergeVertices } from "three/examples/jsm/utils/BufferGeometryUtils.js";

const OUTLINE_SAMPLES = 4000;
const ANGLE_BINS = 720;
// The point the heart "grows" from. Slightly below the middle looks natural.
const CENTER = new THREE.Vector2(0, -0.05);

/** 2D heart silhouette (classic parametric heart), centered and scaled to 2 units wide. */
function heartOutline(): THREE.Vector2[] {
  const raw: THREE.Vector2[] = [];
  for (let i = 0; i < OUTLINE_SAMPLES; i++) {
    const t = (i / OUTLINE_SAMPLES) * Math.PI * 2;
    raw.push(
      new THREE.Vector2(
        16 * Math.pow(Math.sin(t), 3),
        13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)
      )
    );
  }
  const box = new THREE.Box2().setFromPoints(raw);
  const mid = box.getCenter(new THREE.Vector2());
  const s = 2 / (box.max.x - box.min.x);
  return raw.map((p) => p.sub(mid).multiplyScalar(s));
}

/** For each direction (angle) around CENTER, how far away is the heart outline? */
function radiusTable(outline: THREE.Vector2[]): Float32Array {
  const table = new Float32Array(ANGLE_BINS);
  const angles = outline.map((p) => Math.atan2(p.y - CENTER.y, p.x - CENTER.x));
  const dists = outline.map((p) => p.distanceTo(CENTER));
  for (let b = 0; b < ANGLE_BINS; b++) {
    const a = (b / ANGLE_BINS) * Math.PI * 2 - Math.PI;
    let bestD = Infinity;
    for (let i = 0; i < outline.length; i++) {
      let d = Math.abs(angles[i] - a);
      if (d > Math.PI) d = Math.PI * 2 - d;
      if (d < bestD) {
        bestD = d;
        table[b] = dists[i];
      }
    }
  }
  return table;
}

function radiusAt(table: Float32Array, angle: number): number {
  const f = ((angle + Math.PI) / (Math.PI * 2)) * ANGLE_BINS;
  const i0 = Math.floor(f) % ANGLE_BINS;
  const i1 = (i0 + 1) % ANGLE_BINS;
  const w = f - Math.floor(f);
  return table[i0] * (1 - w) + table[i1] * w;
}

/**
 * Heart shell: a sphere whose x/y are stretched, direction by direction,
 * so its equator matches the heart outline. z is just squashed for depth.
 */
export function buildHeartGeometry(thickness = 0.55): THREE.BufferGeometry {
  const table = radiusTable(heartOutline());
  let geo: THREE.BufferGeometry = new THREE.SphereGeometry(1, 96, 64);
  geo.rotateX(Math.PI / 2); // sphere poles now point along z (front / back)

  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    const rho = Math.hypot(x, y); // 0 at the poles, 1 at the equator
    const a = Math.atan2(y, x);
    const R = radiusAt(table, a);
    pos.setXYZ(
      i,
      CENTER.x + rho * R * Math.cos(a),
      CENTER.y + rho * R * Math.sin(a),
      z * thickness
    );
  }

  geo.deleteAttribute("normal");
  geo.deleteAttribute("uv");
  geo = mergeVertices(geo); // removes the UV seam so shading is smooth
  geo.computeVertexNormals();
  return geo;
}

/**
 * Turn 2D waypoints into a 3D curve lying on the shell surface.
 * 1) smooth the waypoints in 2D, 2) sample many points,
 * 3) shoot a ray from the front at each point to find the surface,
 * 4) lift slightly along the surface normal so the tube sits on top.
 */
export function buildArteryCurve(
  shell: THREE.Mesh,
  waypoints: [number, number][],
  lift: number
): THREE.CatmullRomCurve3 {
  const ray = new THREE.Raycaster();
  const down = new THREE.Vector3(0, 0, -1);

  const flat = new THREE.CatmullRomCurve3(
    waypoints.map(([x, y]) => new THREE.Vector3(x, y, 0)),
    false,
    "centripetal"
  );

  const pts = flat.getSpacedPoints(80).map((p) => {
    ray.set(new THREE.Vector3(p.x, p.y, 5), down);
    const hit = ray.intersectObject(shell, false)[0];
    if (!hit || !hit.face) {
      throw new Error(`Artery point (${p.x.toFixed(2)}, ${p.y.toFixed(2)}) is outside the heart shell`);
    }
    return hit.point.clone().addScaledVector(hit.face.normal, lift);
  });

  return new THREE.CatmullRomCurve3(pts, false, "centripetal");
}
