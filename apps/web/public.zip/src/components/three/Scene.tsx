"use client";

import { Canvas } from "@react-three/fiber";
import { OrbitControls, ContactShadows } from "@react-three/drei";
import { useRiskStore } from "@/store/useRiskStore";
import Heart from "./Heart";

export default function Scene() {
  const select = useRiskStore((s) => s.select);

  return (
    <Canvas
      camera={{ position: [0, 0, 3.6], fov: 40 }}
      dpr={[1, 1.5]} // cap pixel ratio so it stays smooth without a dedicated GPU
      style={{ background: "radial-gradient(circle at 50% 40%, #1e293b 0%, #0b1020 75%)" }}
      onPointerMissed={() => select(null)} // click empty space = deselect
    >
      <ambientLight intensity={0.6} />
      <directionalLight position={[3, 4, 5]} intensity={1.8} />
      <directionalLight position={[-4, -2, -3]} intensity={0.7} />
      <directionalLight position={[0, 3, -4]} intensity={0.8} />

      <Heart clinicalView={false} />

      <ContactShadows position={[0, -1.15, 0]} opacity={0.45} blur={2.5} scale={4} />

      <OrbitControls enablePan={false} enableDamping minDistance={2} maxDistance={7} />
    </Canvas>
  );
}