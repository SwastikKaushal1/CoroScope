"use client";

import { useGLTF } from "@react-three/drei";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { ARTERIES } from "@/config/arteries";
import Artery from "./Artery";

const MODEL_URL = "/models/heart.glb";
const LIFT = 0.012; // how far tubes sit above the surface (scene units)
const SAMPLES = 60; // points per artery after snapping
const DEBUG_PICK = true; // click the heart to print coordinates; set false when done

type HeartProps = {
  targetHeight?: number;
  rotation?: [number, number, number];
  position?: [number, number, number];
  /** true = pale uniform heart so risk colours stand out; false = original textures */
  clinicalView?: boolean;
};

export function Heart({
  targetHeight = 2,
  rotation = [0, 0, 0],
  position = [0, 0, 0],
  clinicalView = true,
}: HeartProps) {
  const { scene } = useGLTF(MODEL_URL);
  const model = useMemo(() => scene.clone(true), [scene]);
  const groupRef = useRef<THREE.Group>(null);

  const { scale, offset } = useMemo(() => {
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    return { scale: targetHeight / (size.y || 1), offset: center.multiplyScalar(-1) };
  }, [model, targetHeight]);

  // Remember the original materials so we can switch views.
  const originals = useMemo(() => {
    const map = new Map<THREE.Mesh, THREE.Material | THREE.Material[]>();
    model.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) map.set(m, m.material);
    });
    return map;
  }, [model]);

  const clinicalMat = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: "#d8c3bd",
        roughness: 0.55,
        metalness: 0,
        side: THREE.DoubleSide,
      }),
    []
  );

  useLayoutEffect(() => {
    originals.forEach((orig, mesh) => {
      if (!mesh.geometry.attributes.normal) mesh.geometry.computeVertexNormals();
      if (clinicalView) {
        mesh.material = clinicalMat;
      } else {
        mesh.material = orig;
        const m = orig as THREE.MeshStandardMaterial;
        m.transparent = false;
        m.opacity = 1;
        m.side = THREE.DoubleSide;
        m.needsUpdate = true;
      }
    });
  }, [originals, clinicalView, clinicalMat]);

  // Build curves: take picked waypoints, smooth them, then snap each sample to the surface.
  const curves = useMemo(() => {
    const probeRoot = new THREE.Group();
    const probeModel = model.clone(true);
    probeModel.position.copy(offset);
    probeRoot.scale.setScalar(scale);
    probeRoot.add(probeModel);
    probeRoot.updateMatrixWorld(true);

    const probeMat = new THREE.MeshBasicMaterial({ side: THREE.DoubleSide });
    const meshes: THREE.Mesh[] = [];
    probeModel.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.material = probeMat;
        meshes.push(m);
      }
    });

    const ray = new THREE.Raycaster();

    return ARTERIES.map((def) => {
      if (!def.waypoints || def.waypoints.length < 2) return { def, curve: null };
      const rough = new THREE.CatmullRomCurve3(
        def.waypoints.map(([x, y, z]) => new THREE.Vector3(x, y, z))
      );
      const snapped: THREE.Vector3[] = [];
      for (let i = 0; i < SAMPLES; i++) {
        const p = rough.getPoint(i / (SAMPLES - 1));
        const dir = p.clone().normalize();
        ray.set(p.clone().add(dir.clone().multiplyScalar(1.5)), dir.clone().negate());
        const hit = ray.intersectObjects(meshes, false)[0];
        snapped.push(hit ? hit.point.clone().add(dir.multiplyScalar(LIFT)) : p);
      }
      return { def, curve: new THREE.CatmullRomCurve3(snapped) };
    });
  }, [model, offset, scale]);

  return (
    <group ref={groupRef} rotation={rotation} position={position}>
      <group scale={scale}>
        <primitive
          object={model}
          position={offset}
          onClick={
            DEBUG_PICK
              ? (e: any) => {
                  e.stopPropagation();
                  const p = groupRef.current!.worldToLocal(e.point.clone());
                  console.log(`[${p.x.toFixed(3)}, ${p.y.toFixed(3)}, ${p.z.toFixed(3)}],`);
                }
              : undefined
          }
        />
      </group>
      {curves.map(({ def, curve }) =>
        curve ? <Artery key={def.id} def={def} curve={curve} /> : null
      )}
    </group>
  );
}

useGLTF.preload(MODEL_URL);

export default Heart;